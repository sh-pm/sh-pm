GROUP_ID=bash
ARTIFACT_ID=
VERSION=v0.1.0

declare -A DEPENDENCIES=( \
    [sh-pm]=v3.3.0@github.com/sh-pm
    [sh-logger]=v1.4.0@github.com/sh-logger \
    [sh-unit]=v1.5.4@@github.com/sh-unit \
    [sh-commons]=v1.7.1@github.com/sh-commons \    
);