GROUP_ID=bash
ARTIFACT_ID=
VERSION=v0.1.0

declare -A DEPENDENCIES=( \
    [sh-pm]=v4.0.0@github.com/sh-pm \
    [sh-logger]=v1.4.0@github.com/sh-pm \
    [sh-unit]=v1.5.4@github.com/sh-pm \
    [sh-commons]=v2.0.0@github.com/sh-pm \    
);